<?php
/**
 * Payee Webhook Handler
 *
 * Listens for asynchronous payment status notifications sent by
 * the gateway to the WC-API endpoint registered below.
 *
 * Callback URL format:
 *   https://yourstore.com/?wc-api=payee_webhook
 *
 * The gateway sends a JSON POST with transaction status updates.
 * This handler validates the signature, then updates the WooCommerce
 * order accordingly.
 *
 * @package WooCommerce_Payee
 */

defined( 'ABSPATH' ) || exit;

class Payee_Webhook_Handler {

    /**
     * Register the WC-API hook.
     * Called once on plugins_loaded via the gateway constructor.
     */
    public static function init() {
        add_action( 'woocommerce_api_payee_webhook', array( __CLASS__, 'handle' ) );
    }

    /**
     * Handle an incoming webhook notification.
     */
    public static function handle() {

        $raw_body = file_get_contents( 'php://input' );

        Payee_Logger::debug( 'Payee webhook received: ' . $raw_body );

        // Retrieve gateway settings so we can validate the signature.
        $gateway_settings = get_option( 'woocommerce_payee_settings', array() );
        $shared_secret    = isset( $gateway_settings['shared_secret'] ) ? $gateway_settings['shared_secret'] : '';

        // Validate the HMAC-SHA512 signature sent in the header.
        $received_signature = isset( $_SERVER['HTTP_X_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_SIGNATURE'] ) ) : '';

        if ( ! self::validate_signature( $raw_body, $received_signature, $shared_secret ) ) {
            Payee_Logger::warning( 'Payee webhook signature mismatch. Ignoring notification.' );
            status_header( 401 );
            exit( 'Unauthorized' );
        }

        $data = json_decode( $raw_body, true );

        if ( json_last_error() !== JSON_ERROR_NONE || empty( $data ) ) {
            Payee_Logger::error( 'Payee webhook: invalid JSON payload.' );
            status_header( 400 );
            exit( 'Bad Request' );
        }

        self::process_notification( $data );

        status_header( 200 );
        exit( 'OK' );
    }

    /**
     * Process a decoded notification payload and update the order.
     *
     * @param array $data Decoded JSON notification.
     */
    private static function process_notification( array $data ) {

        $merchant_transaction_id = isset( $data['merchantTransactionId'] ) ? sanitize_text_field( $data['merchantTransactionId'] ) : '';
        $transaction_status      = isset( $data['transactionStatus'] )     ? sanitize_text_field( $data['transactionStatus'] )     : '';
        $gateway_uuid            = isset( $data['uuid'] )                  ? sanitize_text_field( $data['uuid'] )                  : '';

        if ( empty( $merchant_transaction_id ) ) {
            Payee_Logger::warning( 'Payee webhook: missing merchantTransactionId.' );
            return;
        }

        // The merchantTransactionId we send is the WC order ID.
        $order = wc_get_order( absint( $merchant_transaction_id ) );

        if ( ! $order ) {
            Payee_Logger::warning( 'Payee webhook: order not found for ID ' . $merchant_transaction_id );
            return;
        }

        // Avoid processing the same final status twice.
        if ( $order->has_status( array( 'completed', 'processing', 'cancelled', 'failed' ) ) ) {
            Payee_Logger::info( sprintf( 'Payee webhook: order #%s already in final status, skipping.', $order->get_id() ) );
            return;
        }

        switch ( strtoupper( $transaction_status ) ) {

            case 'SUCCESS':
                $order->payment_complete( $gateway_uuid );
                $order->add_order_note(
                    sprintf(
                        /* translators: %s: gateway transaction UUID */
                        esc_html__( 'Payee payment confirmed via webhook. Transaction ID: %s', 'woocommerce-payee' ),
                        $gateway_uuid
                    )
                );
                Payee_Logger::info( 'Payee webhook: order #' . $order->get_id() . ' marked as payment_complete.' );
                break;

            case 'FAILED':
            case 'ERROR':
                $order->update_status(
                    'failed',
                    esc_html__( 'Payee payment failed (webhook notification).', 'woocommerce-payee' )
                );
                Payee_Logger::warning( 'Payee webhook: order #' . $order->get_id() . ' marked as failed.' );
                break;

            case 'PENDING':
            case 'AWAITING':
                $order->update_status(
                    'on-hold',
                    esc_html__( 'Payee payment pending confirmation (webhook notification).', 'woocommerce-payee' )
                );
                Payee_Logger::info( 'Payee webhook: order #' . $order->get_id() . ' marked as on-hold.' );
                break;

            default:
                Payee_Logger::info( 'Payee webhook: unhandled transaction status "' . $transaction_status . '" for order #' . $order->get_id() );
                break;
        }
    }

    /**
     * Validate the HMAC-SHA512 signature from the webhook header.
     *
     * @param string $raw_body          Raw request body string.
     * @param string $received_signature Signature header value.
     * @param string $shared_secret      Gateway shared secret.
     * @return bool
     */
    private static function validate_signature( $raw_body, $received_signature, $shared_secret ) {
        if ( empty( $shared_secret ) || empty( $received_signature ) ) {
            return false;
        }
        $expected = hash_hmac( 'sha512', $raw_body, $shared_secret );
        return hash_equals( $expected, $received_signature );
    }
}
