<?php
/**
 * Payee API Client
 *
 * Handles all HTTP communication with the payment gateway.
 * Credentials and endpoint details are abstracted here so
 * the rest of the plugin only knows about "Payee".
 *
 * @package WooCommerce_Payee
 */

defined( 'ABSPATH' ) || exit;

class Payee_API {

    /**
     * Live gateway base URL.
     */
    const LIVE_URL = 'https://gateway.tillpayments.com/api/v3';

    /**
     * Sandbox gateway base URL.
     */
    const SANDBOX_URL = 'https://gateway.tillpayments.com/api/v3';

    /** @var string API key (connector key). */
    private $api_key;

    /** @var string Shared secret for request signing. */
    private $shared_secret;

    /** @var bool Whether to use sandbox mode. */
    private $sandbox;

    /**
     * Constructor.
     *
     * @param string $api_key       Connector API key.
     * @param string $shared_secret Connector shared secret.
     * @param bool   $sandbox       True for sandbox/test mode.
     */
    public function __construct( $api_key, $shared_secret, $sandbox = false ) {
        $this->api_key       = $api_key;
        $this->shared_secret = $shared_secret;
        $this->sandbox       = $sandbox;
    }

    // -------------------------------------------------------------------------
    // Public API methods
    // -------------------------------------------------------------------------

    /**
     * Initiate a debit (charge) transaction.
     *
     * @param array $payload  Transaction payload.
     * @return array          Parsed API response.
     */
    public function debit( array $payload ) {
        return $this->request( 'POST', '/transaction/' . $this->api_key . '/debit', $payload );
    }

    /**
     * Initiate a preauthorisation (hold funds without capture).
     *
     * @param array $payload  Transaction payload.
     * @return array          Parsed API response.
     */
    public function preauthorize( array $payload ) {
        return $this->request( 'POST', '/transaction/' . $this->api_key . '/preauthorize', $payload );
    }

    /**
     * Capture a previously preauthorised transaction.
     *
     * @param string $reference_id UUID from the original preauthorise call.
     * @param array  $payload      Capture payload (amount, currency, etc.).
     * @return array               Parsed API response.
     */
    public function capture( $reference_id, array $payload ) {
        $payload['referenceTransactionId'] = $reference_id;
        return $this->request( 'POST', '/transaction/' . $this->api_key . '/capture', $payload );
    }

    /**
     * Register a customer card for future recurring use.
     *
     * @param array $payload  Registration payload.
     * @return array          Parsed API response.
     */
    public function register( array $payload ) {
        return $this->request( 'POST', '/transaction/' . $this->api_key . '/register', $payload );
    }

    // -------------------------------------------------------------------------
    // Request builder
    // -------------------------------------------------------------------------

    /**
     * Send an authenticated JSON request to the gateway.
     *
     * @param string $method   HTTP method (POST|GET).
     * @param string $endpoint Path relative to the base URL, e.g. /transaction/{apiKey}/debit.
     * @param array  $body     Request body data (will be JSON-encoded).
     * @return array           Associative array of the decoded JSON response.
     * @throws Exception       On transport or non-200 HTTP errors.
     */
    private function request( $method, $endpoint, array $body = array() ) {

        $url          = $this->base_url() . $endpoint;
        $json_body    = wp_json_encode( $body );
        $timestamp    = (string) time();
        $content_type = 'application/json';

        // Build HMAC-SHA512 signature: method + endpoint + MD5(body) + content-type + timestamp.
        $body_hash = md5( $json_body );
        $sign_string = strtolower( $method ) . $endpoint . $body_hash . $content_type . $timestamp;
        $signature   = hash_hmac( 'sha512', $sign_string, $this->shared_secret );

        $args = array(
            'method'  => $method,
            'timeout' => 45,
            'headers' => array(
                'Content-Type'    => $content_type,
                'Accept'          => 'application/json',
                'X-Date'          => $timestamp,
                'X-Signature'     => $signature,
            ),
            'body'    => $json_body,
        );

        Payee_Logger::debug( sprintf( 'Payee API %s %s', $method, $url ) );

        $response = wp_remote_request( $url, $args );

        if ( is_wp_error( $response ) ) {
            $error_message = $response->get_error_message();
            Payee_Logger::error( 'Payee API WP_Error: ' . $error_message );
            throw new Exception( esc_html( $error_message ) );
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        $raw_body  = wp_remote_retrieve_body( $response );

        Payee_Logger::debug( sprintf( 'Payee API response [HTTP %d]: %s', $http_code, $raw_body ) );

        $decoded = json_decode( $raw_body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            Payee_Logger::error( 'Payee API returned non-JSON response.' );
            throw new Exception( esc_html__( 'Invalid response from payment gateway.', 'woocommerce-payee' ) );
        }

        return $decoded;
    }

    /**
     * Return the correct base URL based on sandbox mode.
     *
     * @return string
     */
    private function base_url() {
        return $this->sandbox ? self::SANDBOX_URL : self::LIVE_URL;
    }
}
