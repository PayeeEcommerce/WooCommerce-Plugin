<?php
/**
 * WC_Payee_Gateway
 *
 * Extends WC_Payment_Gateway to add Payee as a payment option
 * on the WooCommerce checkout page.
 *
 * @package WooCommerce_Payee
 */

defined( 'ABSPATH' ) || exit;

class WC_Payee_Gateway extends WC_Payment_Gateway {

    /**
     * Constructor — sets gateway properties and hooks.
     */
    public function __construct() {

        $this->id                 = 'payee';
        $this->method_title       = __( 'Payee', 'woocommerce-payee' );
        $this->method_description = __( 'Accept credit and debit card payments securely via Payee.', 'woocommerce-payee' );
        $this->has_fields         = true;
        $this->supports           = array( 'products' );

        // Logo shown at checkout.
        $this->icon = apply_filters(
            'woocommerce_payee_icon',
            PAYEE_PLUGIN_URL . 'assets/images/payee-logo.png'
        );

        // Load settings fields and saved values.
        $this->init_form_fields();
        $this->init_settings();

        // Map settings to instance properties.
        $this->title          = $this->get_option( 'title' );
        $this->description    = $this->get_option( 'description' );
        $this->enabled        = $this->get_option( 'enabled' );
        $this->sandbox        = 'yes' === $this->get_option( 'sandbox' );
        $this->api_key        = $this->get_option( 'api_key' );
        $this->shared_secret  = $this->get_option( 'shared_secret' );
        $this->debug          = 'yes' === $this->get_option( 'debug' );

        // Append sandbox badge to the gateway title when in test mode.
        if ( $this->sandbox ) {
            $this->title .= ' ' . __( '[TEST MODE]', 'woocommerce-payee' );
        }

        // Save settings from the admin page.
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

        // Enqueue frontend checkout scripts.
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        // Register the webhook handler.
        Payee_Webhook_Handler::init();
    }

    // -------------------------------------------------------------------------
    // Admin settings
    // -------------------------------------------------------------------------

    /**
     * Define the admin settings form fields.
     */
    public function init_form_fields() {

        $this->form_fields = array(

            'enabled' => array(
                'title'   => __( 'Enable / Disable', 'woocommerce-payee' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable Payee Payment Gateway', 'woocommerce-payee' ),
                'default' => 'no',
            ),

            'title' => array(
                'title'       => __( 'Title', 'woocommerce-payee' ),
                'type'        => 'text',
                'description' => __( 'Payment method title shown to customers at checkout.', 'woocommerce-payee' ),
                'default'     => __( 'Credit / Debit Card', 'woocommerce-payee' ),
                'desc_tip'    => true,
            ),

            'description' => array(
                'title'       => __( 'Description', 'woocommerce-payee' ),
                'type'        => 'textarea',
                'description' => __( 'Payment method description shown to customers at checkout.', 'woocommerce-payee' ),
                'default'     => __( 'Pay securely with your credit or debit card via Payee.', 'woocommerce-payee' ),
                'desc_tip'    => true,
            ),

            'api_credentials_section' => array(
                'title' => __( 'API Credentials', 'woocommerce-payee' ),
                'type'  => 'title',
                'description' => __( 'Enter the credentials provided in your Payee merchant portal.', 'woocommerce-payee' ),
            ),

            'api_key' => array(
                'title'       => __( 'API Key', 'woocommerce-payee' ),
                'type'        => 'password',
                'description' => __( 'Your Payee connector API key.', 'woocommerce-payee' ),
                'default'     => '',
                'desc_tip'    => true,
            ),

            'shared_secret' => array(
                'title'       => __( 'Shared Secret', 'woocommerce-payee' ),
                'type'        => 'password',
                'description' => __( 'Your Payee shared secret used for request signing and webhook validation.', 'woocommerce-payee' ),
                'default'     => '',
                'desc_tip'    => true,
            ),

            'advanced_section' => array(
                'title' => __( 'Advanced', 'woocommerce-payee' ),
                'type'  => 'title',
            ),

            'sandbox' => array(
                'title'       => __( 'Sandbox / Test Mode', 'woocommerce-payee' ),
                'type'        => 'checkbox',
                'label'       => __( 'Enable test mode — no real charges will be made.', 'woocommerce-payee' ),
                'default'     => 'yes',
                'description' => sprintf(
                    /* translators: %s: webhook URL */
                    __( 'When enabled, test credentials will be used. Your webhook URL is: <code>%s</code>', 'woocommerce-payee' ),
                    esc_url( home_url( '/?wc-api=payee_webhook' ) )
                ),
            ),

            'debug' => array(
                'title'       => __( 'Debug Logging', 'woocommerce-payee' ),
                'type'        => 'checkbox',
                'label'       => __( 'Enable detailed debug logging.', 'woocommerce-payee' ),
                'default'     => 'no',
                'description' => sprintf(
                    /* translators: %s: link to WooCommerce logs */
                    __( 'Log Payee events to <a href="%s">WooCommerce > Status > Logs</a>.', 'woocommerce-payee' ),
                    esc_url( admin_url( 'admin.php?page=wc-status&tab=logs' ) )
                ),
            ),
        );
    }

    // -------------------------------------------------------------------------
    // Checkout fields
    // -------------------------------------------------------------------------

    /**
     * Render the card input fields on the checkout page.
     * Card data is tokenised client-side via payment.js before submission —
     * the raw PAN never touches your server.
     */
    public function payment_fields() {
        if ( $this->description ) {
            echo '<p>' . wp_kses_post( $this->description ) . '</p>';
        }

        if ( $this->sandbox ) {
            echo '<p class="payee-test-notice">' . esc_html__( 'TEST MODE ACTIVE — use test card details only.', 'woocommerce-payee' ) . '</p>';
        }
        ?>
        <fieldset id="payee-card-fields" class="wc-credit-card-form wc-payment-form">
            <div class="form-row form-row-wide">
                <label for="payee_card_number">
                    <?php esc_html_e( 'Card Number', 'woocommerce-payee' ); ?>
                    <span class="required">*</span>
                </label>
                <div id="payee_card_number" class="payee-js-field"></div>
            </div>

            <div class="form-row form-row-first">
                <label for="payee_card_expiry">
                    <?php esc_html_e( 'Expiry (MM / YY)', 'woocommerce-payee' ); ?>
                    <span class="required">*</span>
                </label>
                <input id="payee_card_expiry"
                       class="input-text"
                       type="text"
                       autocomplete="cc-exp"
                       placeholder="MM / YY"
                       maxlength="7" />
            </div>

            <div class="form-row form-row-last">
                <label for="payee_card_cvc">
                    <?php esc_html_e( 'CVV', 'woocommerce-payee' ); ?>
                    <span class="required">*</span>
                </label>
                <div id="payee_card_cvc" class="payee-js-field"></div>
            </div>

            <!-- Token produced by payment.js — submitted with the WC order form -->
            <input type="hidden" id="payee_token" name="payee_token" />
            <div class="clear"></div>
        </fieldset>
        <?php
    }

    /**
     * Validate the fields before process_payment() is called.
     *
     * @return bool
     */
    public function validate_fields() {

        // Expect payment.js to have placed a token in payee_token.
        $token = isset( $_POST['payee_token'] ) ? sanitize_text_field( wp_unslash( $_POST['payee_token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

        if ( empty( $token ) ) {
            wc_add_notice(
                __( 'Payment error: card details could not be processed. Please try again.', 'woocommerce-payee' ),
                'error'
            );
            return false;
        }

        return true;
    }

    // -------------------------------------------------------------------------
    // Payment processing
    // -------------------------------------------------------------------------

    /**
     * Process the payment for a given order.
     *
     * Called by WooCommerce when the customer submits the checkout form.
     *
     * @param int $order_id WooCommerce order ID.
     * @return array        Result array with 'result' and 'redirect' keys.
     */
    public function process_payment( $order_id ) {

        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            Payee_Logger::error( 'process_payment: order not found — ID ' . $order_id );
            wc_add_notice( __( 'Order not found. Please contact support.', 'woocommerce-payee' ), 'error' );
            return array( 'result' => 'failure' );
        }

        // Retrieve the card token produced by payment.js.
        $token = isset( $_POST['payee_token'] ) ? sanitize_text_field( wp_unslash( $_POST['payee_token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

        // Build the transaction payload.
        $payload = array(
            'merchantTransactionId' => (string) $order_id,
            'amount'                => number_format( $order->get_total(), 2, '.', '' ),
            'currency'              => get_woocommerce_currency(),
            'successUrl'            => $this->get_return_url( $order ),
            'cancelUrl'             => wc_get_cart_url(),
            'errorUrl'              => wc_get_cart_url(),
            'callbackUrl'           => home_url( '/?wc-api=payee_webhook' ),
            'description'           => sprintf(
                /* translators: 1: blog name, 2: order ID */
                __( 'Order #%2$s from %1$s', 'woocommerce-payee' ),
                get_bloginfo( 'name' ),
                $order->get_order_number()
            ),
            'customer' => array(
                'firstName'      => $order->get_billing_first_name(),
                'lastName'       => $order->get_billing_last_name(),
                'email'          => $order->get_billing_email(),
                'billingAddress1'=> $order->get_billing_address_1(),
                'billingCity'    => $order->get_billing_city(),
                'billingState'   => $order->get_billing_state(),
                'billingPostcode'=> $order->get_billing_postcode(),
                'billingCountry' => $order->get_billing_country(),
                'ipAddress'      => WC_Geolocation::get_ip_address(),
            ),
            'transactionToken' => $token,
        );

        Payee_Logger::info( 'Processing payment for order #' . $order_id );

        try {
            $api      = $this->get_api_client();
            $response = $api->debit( $payload );

            return $this->handle_api_response( $order, $response );

        } catch ( Exception $e ) {
            Payee_Logger::error( 'process_payment exception: ' . $e->getMessage() );
            wc_add_notice(
                __( 'Payment could not be processed. Please try again or contact support.', 'woocommerce-payee' ),
                'error'
            );
            return array( 'result' => 'failure' );
        }
    }

    // -------------------------------------------------------------------------
    // Response handling
    // -------------------------------------------------------------------------

    /**
     * Interpret the gateway response and update the order status accordingly.
     *
     * @param WC_Order $order    The WooCommerce order.
     * @param array    $response Decoded API response array.
     * @return array             WooCommerce result array.
     */
    private function handle_api_response( WC_Order $order, array $response ) {

        $return_type = isset( $response['returnType'] ) ? strtoupper( $response['returnType'] ) : '';
        $success     = isset( $response['success'] )    ? (bool) $response['success']           : false;
        $uuid        = isset( $response['uuid'] )       ? sanitize_text_field( $response['uuid'] ) : '';

        // Store the gateway UUID on the order for reference.
        if ( $uuid ) {
            $order->update_meta_data( '_payee_transaction_id', $uuid );
            $order->save();
        }

        switch ( $return_type ) {

            case 'FINISHED':
                if ( $success ) {
                    // Payment completed inline.
                    $order->payment_complete( $uuid );
                    $order->add_order_note(
                        sprintf(
                            /* translators: %s: gateway transaction UUID */
                            esc_html__( 'Payee payment completed. Transaction ID: %s', 'woocommerce-payee' ),
                            $uuid
                        )
                    );
                    WC()->cart->empty_cart();
                    Payee_Logger::info( 'Order #' . $order->get_id() . ' payment_complete. UUID: ' . $uuid );
                    return array(
                        'result'   => 'success',
                        'redirect' => $this->get_return_url( $order ),
                    );
                }

                // Finished but not successful — surface the gateway error message.
                $error_msg = $this->extract_error_message( $response );
                $order->update_status( 'failed', $error_msg );
                wc_add_notice( $error_msg, 'error' );
                Payee_Logger::warning( 'Order #' . $order->get_id() . ' FINISHED but failed. ' . $error_msg );
                return array( 'result' => 'failure' );

            case 'REDIRECT':
                // 3DS or hosted-page redirect required.
                $redirect_url = isset( $response['redirectUrl'] ) ? esc_url_raw( $response['redirectUrl'] ) : '';
                if ( empty( $redirect_url ) ) {
                    wc_add_notice( __( 'Payment error: no redirect URL received.', 'woocommerce-payee' ), 'error' );
                    return array( 'result' => 'failure' );
                }
                $order->update_status( 'pending', __( 'Awaiting Payee payment (redirect).', 'woocommerce-payee' ) );
                Payee_Logger::info( 'Order #' . $order->get_id() . ' redirecting to hosted page.' );
                return array(
                    'result'   => 'success',
                    'redirect' => $redirect_url,
                );

            case 'PENDING':
                $order->update_status( 'on-hold', __( 'Payee payment pending — awaiting confirmation.', 'woocommerce-payee' ) );
                WC()->cart->empty_cart();
                Payee_Logger::info( 'Order #' . $order->get_id() . ' set to on-hold (PENDING).' );
                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url( $order ),
                );

            default:
                $error_msg = $this->extract_error_message( $response );
                wc_add_notice( $error_msg, 'error' );
                Payee_Logger::error( 'Order #' . $order->get_id() . ' unknown returnType: ' . $return_type . '. ' . $error_msg );
                return array( 'result' => 'failure' );
        }
    }

    /**
     * Extract a human-readable error message from a gateway response.
     *
     * @param array $response Decoded API response.
     * @return string
     */
    private function extract_error_message( array $response ) {
        if ( ! empty( $response['errors'] ) && is_array( $response['errors'] ) ) {
            $messages = wp_list_pluck( $response['errors'], 'message' );
            return implode( ' ', array_map( 'sanitize_text_field', $messages ) );
        }
        return __( 'Payment could not be processed. Please try again.', 'woocommerce-payee' );
    }

    // -------------------------------------------------------------------------
    // Assets
    // -------------------------------------------------------------------------

    /**
     * Enqueue checkout CSS and JS (only on the checkout page).
     */
    public function enqueue_scripts() {
        if ( ! is_checkout() || 'no' === $this->enabled ) {
            return;
        }

        wp_enqueue_style(
            'payee-checkout',
            PAYEE_PLUGIN_URL . 'assets/css/payee-checkout.css',
            array(),
            PAYEE_VERSION
        );

        wp_enqueue_script(
            'payee-checkout',
            PAYEE_PLUGIN_URL . 'assets/js/payee-checkout.js',
            array( 'jquery' ),
            PAYEE_VERSION,
            true
        );

        wp_localize_script(
            'payee-checkout',
            'payeeParams',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'sandbox'  => $this->sandbox ? 'yes' : 'no',
            )
        );
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Instantiate and return the Payee API client.
     *
     * @return Payee_API
     */
    private function get_api_client() {
        return new Payee_API( $this->api_key, $this->shared_secret, $this->sandbox );
    }
}
