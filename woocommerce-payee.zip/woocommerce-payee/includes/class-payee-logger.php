<?php
/**
 * Payee Logger
 *
 * Thin wrapper around WooCommerce's WC_Logger so all plugin
 * log entries appear under a single "payee" source in
 * WooCommerce > Status > Logs.
 *
 * @package WooCommerce_Payee
 */

defined( 'ABSPATH' ) || exit;

class Payee_Logger {

    const SOURCE = 'payee';

    /**
     * Write a log entry.
     *
     * @param string $message  Human-readable message.
     * @param string $level    WC_Log_Levels constant (debug|info|notice|warning|error|critical).
     * @param array  $context  Optional additional context data.
     */
    public static function log( $message, $level = 'info', $context = array() ) {
        if ( ! function_exists( 'wc_get_logger' ) ) {
            return;
        }

        $logger  = wc_get_logger();
        $context = array_merge( array( 'source' => self::SOURCE ), $context );
        $logger->log( $level, $message, $context );
    }

    /** Convenience helpers ------------------------------------------------- */

    public static function debug( $message, $context = array() ) {
        self::log( $message, 'debug', $context );
    }

    public static function info( $message, $context = array() ) {
        self::log( $message, 'info', $context );
    }

    public static function warning( $message, $context = array() ) {
        self::log( $message, 'warning', $context );
    }

    public static function error( $message, $context = array() ) {
        self::log( $message, 'error', $context );
    }
}
