=== Payee Payment Gateway ===
Contributors: payee
Tags: woocommerce, payment, gateway, credit card, payee
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Accept credit and debit card payments securely on your WooCommerce store via Payee.

== Description ==

Payee Payment Gateway integrates the Payee payment platform directly into your WooCommerce checkout. Accept Visa, Mastercard, and other major cards with a secure, seamless experience for your customers.

**Features:**

* Direct card payment at checkout — no redirects for supported cards
* 3DS / hosted-page redirect support where required
* Sandbox / Test mode for safe development and testing
* Asynchronous webhook notifications for payment status updates
* Detailed debug logging via WooCommerce > Status > Logs
* HPOS (High-Performance Order Storage) compatible

**Refunds:**
Refunds are managed directly through the Payee merchant portal.

== Installation ==

1. Upload the `woocommerce-payee` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **WooCommerce > Settings > Payments** and click **Manage** next to Payee.
4. Enter your API Key and Shared Secret from the Payee merchant portal.
5. Set your **Webhook / Callback URL** in the Payee portal to: `https://yourstore.com/?wc-api=payee_webhook`
6. Disable **Sandbox Mode** when you are ready to accept live payments.

== Frequently Asked Questions ==

= Where do I find my API credentials? =
Log in to your Payee merchant portal at https://payee.net.au and navigate to Settings > API Credentials.

= How do refunds work? =
Refunds are processed directly inside the Payee merchant portal. They are not available from within WooCommerce.

= Is test mode available? =
Yes. Enable **Sandbox / Test Mode** in the gateway settings. No real charges will be made in this mode.

= Where is the webhook URL? =
Your webhook / callback URL is displayed on the gateway settings page. It follows the format: `https://yourstore.com/?wc-api=payee_webhook`

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
