/**
 * Payee Payment Gateway — Checkout JS
 *
 * Initialises the payment.js card fields and intercepts the
 * WooCommerce "Place Order" button to tokenise card data before
 * the form is submitted to the server. The raw card number and
 * CVV never touch your server.
 *
 * @package WooCommerce_Payee
 */
/* global PaymentJs, payeeParams, jQuery */

( function ( $, payeeParams ) {
    'use strict';

    var payment     = null;
    var tokenising  = false;

    /**
     * Initialise payment.js when the Payee payment method is selected.
     */
    function initPaymentJs() {
        if ( payment ) {
            return; // Already initialised.
        }

        // payment.js is loaded from the gateway CDN.
        // The public integration key is embedded by the server via wp_localize_script
        // (add publicKey to payeeParams in class-wc-payee-gateway.php when available).
        payment = new PaymentJs( '1.2' );
        payment.init(
            payeeParams.publicKey || '',
            'payee_card_number',
            'payee_card_cvc',
            function ( payment ) {
                payment.setNumberStyle( {
                    'font-size'    : '14px',
                    'font-family'  : 'inherit',
                    'color'        : '#333',
                    'padding'      : '0 8px',
                    'line-height'  : '38px',
                } );
                payment.setCvvStyle( {
                    'font-size'    : '14px',
                    'font-family'  : 'inherit',
                    'color'        : '#333',
                    'padding'      : '0 8px',
                    'line-height'  : '38px',
                } );
            }
        );
    }

    /**
     * Intercept the WooCommerce checkout form submission when
     * Payee is the selected payment method.
     */
    $( document.body ).on( 'checkout_place_order_payee', function () {

        var $form           = $( 'form.checkout' );
        var selectedMethod  = $( 'input[name="payment_method"]:checked' ).val();

        if ( selectedMethod !== 'payee' ) {
            return true; // Let WooCommerce handle non-Payee methods normally.
        }

        if ( tokenising ) {
            return false; // Prevent double-submission.
        }

        var expiry = $( '#payee_card_expiry' ).val().replace( /\s/g, '' );
        var parts  = expiry.split( '/' );
        var expMonth = parts[0] ? $.trim( parts[0] ) : '';
        var expYear  = parts[1] ? $.trim( parts[1] ) : '';

        // Pad 2-digit year to 4 digits.
        if ( expYear.length === 2 ) {
            expYear = '20' + expYear;
        }

        tokenising = true;
        $form.addClass( 'processing' ).block( {
            message: null,
            overlayCSS: { background: '#fff', opacity: 0.6 },
        } );

        payment.tokenize(
            {
                month : expMonth,
                year  : expYear,
            },
            // Success callback.
            function ( token /*, cardData */ ) {
                $( '#payee_token' ).val( token );
                tokenising = false;
                $form.submit();
            },
            // Error callback.
            function ( errors ) {
                tokenising = false;
                $form.removeClass( 'processing' ).unblock();

                $( '.payee-js-field' ).removeClass( 'payee-field--error' );
                $( '.payee-token-error' ).remove();

                var messages = [];
                if ( errors && errors.length ) {
                    for ( var i = 0; i < errors.length; i++ ) {
                        messages.push( errors[ i ].message );
                        if ( errors[ i ].attribute === 'number' ) {
                            $( '#payee_card_number' ).addClass( 'payee-field--error' );
                        }
                        if ( errors[ i ].attribute === 'cvv' ) {
                            $( '#payee_card_cvc' ).addClass( 'payee-field--error' );
                        }
                    }
                } else {
                    messages.push( 'Card details could not be processed. Please check and try again.' );
                }

                $( '.woocommerce-error, .woocommerce-message' ).remove();
                $form.prepend(
                    '<ul class="woocommerce-error payee-token-error"><li>' +
                    messages.join( '</li><li>' ) +
                    '</li></ul>'
                );
                $( 'html, body' ).animate( { scrollTop: $form.offset().top - 100 }, 500 );
            }
        );

        return false; // Prevent WooCommerce default submission until tokenised.
    } );

    /**
     * Re-initialise payment.js when the payment method tab is updated
     * (e.g., after an AJAX cart update).
     */
    $( document.body ).on( 'updated_checkout payment_method_selected', function () {
        var selectedMethod = $( 'input[name="payment_method"]:checked' ).val();
        if ( selectedMethod === 'payee' ) {
            initPaymentJs();
        }
    } );

    // Initial run.
    $( function () {
        if ( $( 'input[name="payment_method"][value="payee"]' ).is( ':checked' ) ) {
            initPaymentJs();
        }
    } );

}( jQuery, window.payeeParams || {} ) );
