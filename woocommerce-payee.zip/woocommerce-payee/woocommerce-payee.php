<?php
/**
 * Plugin Name:       Payee Payment Gateway
 * Plugin URI:        https://payee.net.au
 * Description:       Accept credit card payments securely via Payee. Seamlessly integrates with WooCommerce checkout.
 * Version:           1.0.0
 * Author:            Payee
 * Author URI:        https://payee.net.au
 * License:           GNU General Public License v3.0
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       woocommerce-payee
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 6.0
 * WC tested up to:   9.0
 *
 * @package WooCommerce_Payee
 */

defined( 'ABSPATH' ) || exit;

define( 'PAYEE_VERSION',     '1.0.0' );
define( 'PAYEE_PLUGIN_FILE', __FILE__ );
define( 'PAYEE_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'PAYEE_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

/**
 * Declare HPOS (High-Performance Order Storage) compatibility.
 */
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
} );

/**
 * Initialise the gateway once WooCommerce is loaded.
 */
add_action( 'plugins_loaded', 'payee_init_gateway', 11 );

function payee_init_gateway() {

    if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
        add_action( 'admin_notices', 'payee_woocommerce_missing_notice' );
        return;
    }

    // Load plugin classes.
    require_once PAYEE_PLUGIN_DIR . 'includes/class-payee-logger.php';
    require_once PAYEE_PLUGIN_DIR . 'includes/class-payee-api.php';
    require_once PAYEE_PLUGIN_DIR . 'includes/class-payee-webhook-handler.php';
    require_once PAYEE_PLUGIN_DIR . 'includes/class-wc-payee-gateway.php';

    // Register gateway with WooCommerce.
    add_filter( 'woocommerce_payment_gateways', 'payee_add_gateway' );

    // Load text domain for translations.
    load_plugin_textdomain( 'woocommerce-payee', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

/**
 * Register the Payee gateway class.
 *
 * @param array $methods Existing gateway classes.
 * @return array
 */
function payee_add_gateway( $methods ) {
    $methods[] = 'WC_Payee_Gateway';
    return $methods;
}

/**
 * Admin notice when WooCommerce is not active.
 */
function payee_woocommerce_missing_notice() {
    echo '<div class="error"><p>';
    echo esc_html__( 'Payee Payment Gateway requires WooCommerce to be installed and active.', 'woocommerce-payee' );
    echo '</p></div>';
}

/**
 * Add a Settings shortcut link on the Plugins page.
 */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'payee_plugin_action_links' );

function payee_plugin_action_links( $links ) {
    $settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=payee' );
    $plugin_links  = array(
        '<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'woocommerce-payee' ) . '</a>',
    );
    return array_merge( $plugin_links, $links );
}
